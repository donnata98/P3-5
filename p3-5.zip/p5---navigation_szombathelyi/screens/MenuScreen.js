import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';

export function MenuScreen({ route, navigation }) {

function handleHomePress1(){
  navigation.navigate("Home")
}

function handleHomePress2(){
  navigation.navigate("Review")
}

function handleHomePress3(){
  navigation.navigate("Sales")
}

function handleHomePress4(){
  navigation.navigate("Profile")
}

  return (
    <View style={styles.screen}>
     
      <Button 
      title="GO TO THE HOME SCREEN"
      onPress={handleHomePress1}
       />
       <br />

       <Button 
      title="GO TO THE REVIEW SCREEN"
      onPress={handleHomePress2}
       />
       <br />

       <Button 
      title="GO TO THE SALES SCREEN"
      onPress={handleHomePress3}
       />
       <br />

       <Button 
      title="GO TO THE PROFILE SCREEN"
      onPress={handleHomePress4}
       />
       <br />
    </View>
  );
}
const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignContent: "center",
    justifyContent: "center",
    padding: 15
  }
});
