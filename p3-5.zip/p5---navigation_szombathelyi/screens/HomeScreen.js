import React, {useState} from 'react';
import { Text, View, StyleSheet, Button, Image, FlatList } from 'react-native';
import CommentInput from "../components/CommentInput"
import CommentItem from "../components/CommentItem"

export function HomeScreen({ route, navigation }) {


function handleHomePress1(){
  navigation.navigate("Menu")
}

function handleHomePress2(){
  navigation.navigate("Review")
}

function handleHomePress3(){
  navigation.navigate("Sales")
}

function handleHomePress4(){
  navigation.navigate("Profile")
}


  return (
    <View style={styles.screen}>
   
 <Button 
      title="GO TO THE MENU SCREEN"
      onPress={handleHomePress1}
       />
       <br />
        <Button 
      title="GO TO THE REVIEW SCREEN"
      onPress={handleHomePress2}
       />
       <br />
       <Button 
      title="GO TO THE SALES SCREEN"
      onPress={handleHomePress3}
       />
       <br />
        <Button 
      title="GO TO THE PROFILE SCREEN"
      onPress={handleHomePress4}
       />

  

    </View>
  );
}
const styles = StyleSheet.create({
  screen: {
  flex: 1,
    alignContent: "center",
    justifyContent: "center",
    padding: 15
  },
  
});
