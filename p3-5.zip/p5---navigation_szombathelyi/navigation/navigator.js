import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { HomeScreen } from "../screens/HomeScreen";
import { MenuScreen } from "../screens/MenuScreen";
import { SaleScreen } from "../screens/SaleScreen";
import { ProfileScreen } from "../screens/ProfileScreen";
import { ReviewScreen } from "../screens/ReviewScreen";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Ionicons from "@expo/vector-icons/Ionicons";

const Stack = createStackNavigator();

export function MyStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Home"
        component={HomeScreen}
        options={{ title: "Home screen" }}
      />

      <Stack.Screen
        name="Menu"
        component={MenuScreen}
        options={{ title: "Menu screen" }}
      />

        <Stack.Screen
        name="Sales"
        component={SalesScreen}
        options={{ title: "Sales screen" }}
      />

        <Stack.Screen
        name="About"
        component={AboutScreen}
        options={{ title: "About screen" }}
      />

        <Stack.Screen
        name="Profile"
        component={ProfileScreen}
        options={{ title: "Profile screen" }}
      />
    </Stack.Navigator>
  );
}



const Tab = createBottomTabNavigator();

export function TabNavigator() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;


            if (route.name === "Home") {
              iconName = focused ? "home" : "home-outline";
            } 
            else if 
            
            (route.name === "Menu") {
              iconName = focused ? "fast-food" : "fast-food-outline";
            }

            else if 
             (route.name === "Sales") {
              iconName = focused ? "cash" : "cash-outline";
            }

            else if  
            (route.name === "Review") {
              iconName = focused ? "star" : "star-outline";
            }

            else if 
             (route.name === "Profile") {
              iconName = focused ? "person" : "person-outline";
            }



            // You can return any component that you like here!
            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: "blue",
          tabBarInactiveTintColor: "gray",
        })}
      >






        <Tab.Screen
          name="Home"
          component={HomeScreen}
          options={{
            headerTitle: "HOME",
            headerTitleStyle: {
              fontWeight: "bold",
              fontSize: 25,
              paddingBottom: 5,
              color: "#1f4d29",
            },
            headerStyle: {
              borderBottomColor: "gray",
              borderBottomWidth: 0.2,
              shadowColor: "transparent",
            },
            title: "HOME",
            tabBarStyle: {
              paddingTop: 5,
            },
          }}
        />




        <Tab.Screen
          name="Menu"
          component={MenuScreen}
          options={{
            headerTitle: "MENU",
            headerTitleStyle: {
              fontWeight: "bold",
              fontSize: 25,
              paddingBottom: 5,
              color: "#1f4d29",
            },
            headerStyle: {
              borderBottomColor: "gray",
              borderBottomWidth: 0.2,
              shadowColor: "transparent",
            },
            title: "MENU",
            tabBarStyle: {
              paddingTop: 5,
            },
          }}
        />



        <Tab.Screen
          name="Sales"
          component={SaleScreen}
          options={{
            headerTitle: "SALES",
            headerTitleStyle: {
              fontWeight: "bold",
              fontSize: 25,
              paddingBottom: 5,
              color: "#1f4d29",
            },
            headerStyle: {
              borderBottomColor: "gray",
              borderBottomWidth: 0.2,
              shadowColor: "transparent",
            },
            title: "SALES",
            tabBarStyle: {
              paddingTop: 5,
            },
          }}
        />



              <Tab.Screen
          name="Review"
          component={ReviewScreen}
          options={{
            headerTitle: "REVIEW",
            headerTitleStyle: {
              fontWeight: "bold",
              fontSize: 25,
              paddingBottom: 5,
              color: "#1f4d29",
            },
            headerStyle: {
              borderBottomColor: "gray",
              borderBottomWidth: 0.2,
              shadowColor: "transparent",
            },
            title: "REVIEW",
            tabBarStyle: {
              paddingTop: 5,
            },
          }}
        />




 <Tab.Screen
          name="Profile"
          component={ProfileScreen}
          options={{
            headerTitle: "PROFILE",
            headerTitleStyle: {
              fontWeight: "bold",
              fontSize: 25,
              paddingBottom: 5,
              color: "#1f4d29",
            },
            headerStyle: {
              borderBottomColor: "gray",
              borderBottomWidth: 0.2,
              shadowColor: "transparent",
            },
            title: "PROFILE",
            tabBarStyle: {
              paddingTop: 5,
            },
          }}
        />




        
      </Tab.Navigator>
    </NavigationContainer>
  );
}
